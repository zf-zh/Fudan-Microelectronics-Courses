%token		BEGIN_  END_  INPUT_  OUTPUT_  ALWAYS_
%token		LEFT  RIGHT  ASSIGN  COLON  COMMA  SEMI  LB  RB
%token		<stri>	NAME 
%token		<intg>	INTG
%union		{char	stri[100];
		int	intg; }
%start		dffFile
%%
dffFile:	BEGIN_ dffSpec pinSpec END_ ;
dffSpec:	dffName LEFT portList RIGHT SEMI;
portList:	INPUT_ portClock COMMA
		INPUT_ portD COMMA
		OUTPUT_ portQ;
pinSpec:	ALWAYS_ LEFT pinClock RIGHT pinState;
pinState:	netSpec 
	|	pinState netSpec;
dffName:	NAME;
portClock:	NAME{getPortClock($1);};
portD:		NAME;
portQ:		NAME;
pinClock:	NAME{getPinClock($1);};
netSpec:	;
%%
#include "lex.yy.c"
void parse()
{
	yyparse();
	fclose(yyin);
}
