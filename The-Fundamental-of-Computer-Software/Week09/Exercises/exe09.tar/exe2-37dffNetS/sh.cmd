echo "#### dffS4"
cat dffS4
if [ -x dffNetS ]
then
	echo "#### dffNetS < dffS4 > dffS4.net "
	./dffNetS < dffS4 > dffS4.net 
else
	echo "#### dffNetSkey < dffS4 > dffS4.net "
	./dffNetSkey < dffS4 > dffS4.net 
fi
echo "#### cat dffS4.net "
cat dffS4.net
echo "#### "
 
