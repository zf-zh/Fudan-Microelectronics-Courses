%token	FUNCTION_  BEGIN_  END_  RETURN_
%token	<stri>	NAME OP
%token	<intg>	INTG
%token	<real>	REAL
%token	LEFT  RIGHT  EQUAL  COMMA  SEMI
%union	{char	stri[100];
		int	intg;
		float	real;}
%start	file
%%
file:		prog
	|	file  prog
		;
prog:	FUNCTION_
		NAME {printf("FUNCTION %s", $2);}
		LEFT {printf("(");}  para_list  RIGHT {printf(")\n");}
		BEGIN_ {printf("BEGIN\n");}
		state_list
		END_ {printf("END\n");}
		;
para_list:
	|	para
	|	para_list  COMMA {printf(", ");}  para
		;
para:	NAME {printf("%s", $1);} ;
state_list:
	|	state
	|	state_list  state
		;
state:	NAME  EQUAL  {printf("\t%s = ", $1);}
		expr  SEMI {printf(";\n");}
	|	RETURN_  LEFT {printf("\tRETURN(");}
		expr  RIGHT  SEMI {printf(");\n");}
		;
expr:	NAME {printf("%s", $1);}
	|	INTG {printf("%d", $1);}
	|	REAL {printf("%G", $1);}
	|	expr  OP {printf(" %s ", $2);}  expr
	|	LEFT {printf("(");}  expr  RIGHT {printf(")");}
		;

%%
#include "lex.yy.c"
void parse()
{
	yyparse();
	fclose(yyin);
}
