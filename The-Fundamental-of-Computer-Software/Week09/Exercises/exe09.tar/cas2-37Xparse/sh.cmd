echo "#### Xfile"
cat Xfile
echo "#### xparse <Xfile"
xparse <Xfile
echo "#### "
echo "#### Xfile1"
cat Xfile1
echo "#### xparse <Xfile1"
xparse <Xfile1
echo "#### "
echo "#### Xfile2"
cat Xfile2
echo "#### xparse <Xfile2"
xparse <Xfile2
echo "#### "
echo "#### Xfile3"
cat Xfile3
echo "#### xparse <Xfile3"
xparse <Xfile3
echo "#### "
echo "#### Xfile4"
cat Xfile4
echo "#### xparse <Xfile4"
xparse <Xfile4
echo "#### "
echo "#### Xfile5"
cat Xfile5
echo "#### xparse <Xfile5"
xparse <Xfile5
