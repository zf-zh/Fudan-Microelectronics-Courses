#include<stdio.h>
void parse(void);
main()
{
	parse();
} 
