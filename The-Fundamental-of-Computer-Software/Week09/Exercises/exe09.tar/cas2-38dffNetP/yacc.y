%token		BEGIN_  END_  INPUT_  OUTPUT_  ALWAYS_
%token		LEFT  RIGHT  ASSIGN  COLON  COMMA  SEMI  LB  RB
%token		<stri>	NAME
%token		<intg>	INTG
%union		{char	stri[100];
		int	intg; }
%start		dffFile
%%
dffFile:	BEGIN_ dffSpec pinSpec END_;
dffSpec:	dffName LEFT portList RIGHT SEMI;
portList:	clockSpec COMMA inputSpec COMMA outputSpec;
clockSpec:	INPUT_ portClock
inputSpec:	INPUT_ LB bit COLON bit RB{getBitD($<intg>3, $<intg>5);} portD
outputSpec:	OUTPUT_ LB bit COLON bit RB{getBitQ($<intg>3, $<intg>5);} portQ
pinSpec:	ALWAYS_ LEFT pinClock RIGHT
		pinQ ASSIGN pinD SEMI;
dffName:	NAME{getDffName($1);};
portClock:	NAME{getPortClock($1);};
portD:		NAME{getPortD($1);};
portQ:		NAME{getPortQ($1);};
pinClock:	NAME{getPinClock($1);};
pinQ:		NAME{getPinQ($1);};
pinD:		NAME{getPinD($1);};
bit:		INTG;
%%
#include "lex.yy.c"
void parse()
{
	yyparse();
	fclose(yyin);
}
