/* File: dffNetP.c
 	[cas2-28] compile cwparallel dff in Verilog	*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define PORT struct port
#define NET struct net
PORT
{
	char portName[16];
	PORT *next;
};
NET
{
	char netName[16];
	PORT *port;
	NET *next;
};

char DffName[10];
char portD[10], portQ[10], portClock[10];
char pinD[10], pinQ[10], pinClock[10];
NET *Net=NULL;
int LsbD, MsbD, deltaD;
int LsbQ, MsbQ, deltaQ;
char NamePort[10], NameNet[10];

void error(char *string)
{
	printf("%s\n", string);
	exit(0);
}
void getDffName(char *string)
{
	strcpy(DffName, string);
}
void getPortClock(char *string)
{
	strcpy(portClock, string);
}
void getPortD(char *string)
{
	strcpy(portD, string);
}
void getPortQ(char *string)
{
	strcpy(portQ, string);
}
void getBitD(int bit1, int bit2)
{
	LsbD = bit1;
	MsbD = bit2;
	deltaD = bit1<bit2 ? 1 : -1;
}
void getBitQ(int bit1, int bit2)
{
	LsbQ = bit1;
	MsbQ = bit2;
	deltaQ = bit1<bit2 ? 1 : -1;
}
NET *makeNet(char *netName)
{
	NET *net;
	if((net = (NET*)malloc(sizeof(NET))) == NULL)
		error("fail to create NET!");
	strcpy(net->netName, netName);
	net->port = NULL;
	net->next = Net;
	Net = net;
	return(net);
}
void makePort(NET *net)
{
	PORT *port;
	if((port = (PORT*)malloc(sizeof(PORT))) == NULL)
		error("fail to create PORT!");
	strcpy(port->portName, NamePort);
	port->next = net->port;
	net->port = port;
}
void getPinClock(char *string)
{
	NET *net;
	int bit;
	/* make a net for netClock			*/
	strcpy(pinClock, string);
	net = makeNet(portClock);
	/* make and insert portClock into netClock	*/
	strcpy(NamePort, portClock);
	makePort(net);
	/* make and insert port into netClock	*/
	for(bit=LsbD; ; bit+=deltaD)
	{
		if(deltaD > 0 && bit > MsbD)
			break;
		else if(deltaD < 0 && bit < MsbD)
			break;
		sprintf(NamePort, "%s%d->%s\0", DffName, bit, pinClock);
		makePort(net);
	}
}
void getPinQ(char *string)
{
	NET *net;
	int bit;
	strcpy(pinQ, string);
	for(bit=LsbQ; ; bit+=deltaQ)
	{
		if(deltaQ > 0 && bit > MsbQ)
			break;
		else if(deltaQ < 0 && bit < MsbQ)
			break;
		/* make a net for netQ named portQ[bit]	*/
		sprintf(NameNet, "%s[%d]\0", portQ, bit);
		net = makeNet(NameNet);
		/* make and insert port into netQ	*/
		sprintf(NamePort, "%s%d->%s\0", DffName, bit, pinQ);
		makePort(net);
		/* make and insert port into netQ	*/
		sprintf(NamePort, "%s[%d]\0", portQ, bit);
		makePort(net);
	}
}
void getPinD(char *string)
{
	NET *net;
	int bit;
	strcpy(pinD, string);
	for(bit=LsbD; ; bit+=deltaD)
	{
		if(deltaD > 0 && bit > MsbD)
			break;
		else if(deltaD < 0 && bit < MsbD)
			break;
		/* make a net for netD named portD[bit]	*/
		sprintf(NameNet, "%s[%d]\0", portD, bit);
		net = makeNet(NameNet);
		/* make and insert port into netD	*/
		strcpy(NamePort, NameNet);
		makePort(net);
		/* make and insert port into netD	*/
		sprintf(NamePort, "%s%d->%s\0", DffName, bit, pinD);
		makePort(net);
	}
}
void prtPort(PORT *port)
{
	if(port == NULL)
		return;
	prtPort(port->next);
	printf(" %s", port->portName);
}
void prtNet(NET *net)
{
	if(net == NULL)
		return;
	prtNet(net->next);
	printf("%s", net->netName);
	prtPort(net->port);
	printf(";\n");
}
main()
{
	yyparse();
/*	printf("prtNet\n");
*/
	prtNet(Net);
}
