echo "#### dffP4a"
cat dffP4a
echo "#### dffNetP <dffP4a >dffP4a.net "
dffNetP <dffP4a >dffP4a.net 
echo "#### cat dffP4a.net "
cat dffP4a.net
echo "#### "
echo "#### dffP4b"
cat dffP4b
echo "#### dffNetP <dffP4b >dffP4b.net "
dffNetP <dffP4b >dffP4b.net 
echo "#### cat dffP4b.net "
cat dffP4b.net
echo "#### "
echo "#### cat dffP8 "
cat dffP8
echo "#### dffNetP <dffP8 >dffP8.net "
dffNetP <dffP8 >dffP8.net 
echo "#### cat dffP8.net "
cat dffP8.net 
