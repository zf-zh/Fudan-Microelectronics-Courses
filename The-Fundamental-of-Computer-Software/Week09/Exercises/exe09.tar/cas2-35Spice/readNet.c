#include<stdio.h>
void makeRes(char *name,int node1, int node2, float value)
{
	printf("RES: %s %d %d %5.2f\n", name, node1, node2, value);
}
main()
{
	parse();
} 
