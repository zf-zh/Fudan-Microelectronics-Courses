echo "#### readNet <net"
readNet <net
