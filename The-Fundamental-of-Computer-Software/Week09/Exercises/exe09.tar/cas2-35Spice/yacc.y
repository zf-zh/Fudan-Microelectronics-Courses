%token		END_
%token		<intg>	NODE
%token		<real>	VALUE
%token		<stri>	RES
%union		{
		int intg;
		float real;
		char stri[100]; }
%start		spice_file
%%
spice_file:	res_state  END_
		{printf("# of res: %d\n", n_res);} ;
res_state:	resistor {n_res++;}
		| res_state  resistor {n_res++;} ;
resistor:	RES  NODE  NODE  VALUE
		{makeRes($<stri>1, $<intg>2, $<intg>3, $<real>4);} ;
%%
#include "lex.yy.c"
#include "string.h"
void makeRes(char *, int, int, float);
int n_res=0;
void parse()
{
	yyparse();
}
