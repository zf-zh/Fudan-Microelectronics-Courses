#include <stdio.h>
main()
{
	left(); 
	right(); 
}
