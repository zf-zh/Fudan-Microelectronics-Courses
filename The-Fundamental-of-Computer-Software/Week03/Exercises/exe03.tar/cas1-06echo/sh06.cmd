echo "#### sh06 abc xyz "
sh06 abc xyz
