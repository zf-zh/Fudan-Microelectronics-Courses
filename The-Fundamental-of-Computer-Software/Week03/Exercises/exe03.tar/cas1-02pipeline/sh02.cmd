echo "#### tr -cs "[A-Z][a-z][0-9]\.\032" "[\012*]" <text | sort | uniq -c "
tr -cs "[A-Z][a-z][0-9]\.\032" "[\012*]" <text | sort | uniq -c
