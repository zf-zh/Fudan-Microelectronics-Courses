echo "#### sh08B first second third fourth "
sh08B first second third fourth
echo "#### sh08C first second third fourth "
sh08C first second third fourth
