echo "#### sh03B my_cat "
sh03B my_cat
echo "#### sh03C my_cat "
sh03C my_cat
