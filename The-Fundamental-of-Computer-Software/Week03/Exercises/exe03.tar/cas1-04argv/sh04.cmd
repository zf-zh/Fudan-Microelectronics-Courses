echo "#### sh04B file1 file2 "
sh04B file1 file2
echo "#### sh04C file1 file2 "
sh04C file1 file2
