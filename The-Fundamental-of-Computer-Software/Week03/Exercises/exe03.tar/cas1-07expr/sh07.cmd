echo "#### sh07B first second third "
sh07B first second third
echo "#### sh07C first second third "
sh07C first second third
