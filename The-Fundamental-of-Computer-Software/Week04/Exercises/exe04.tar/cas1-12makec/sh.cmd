echo "#### makec cat1 cat2 cat3 "
makec cat1 cat2 cat3
