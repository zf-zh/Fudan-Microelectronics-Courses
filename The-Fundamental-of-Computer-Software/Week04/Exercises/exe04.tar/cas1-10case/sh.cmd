echo "#### sh10B a.o  a.out  a.f "
sh10B a.o  a.out  a.f
echo "#### sh10C a.o  a.out  a.f "
sh10C a.o  a.out  a.f
