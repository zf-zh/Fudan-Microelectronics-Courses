echo "#### sh11B a.c  a.o  a.out  a.f "
sh11B a.c  a.o  a.out  a.f
echo "#### sh11Bash a.c  a.o  a.out  a.f "
sh11Bash a.c  a.o  a.out  a.f
echo "#### sh11C a.c  a.o  a.out  a.f "
sh11C a.c  a.o  a.out  a.f
