echo "#### . sh17 "
. sh17
echo "#### getPasswd"
getPasswd
