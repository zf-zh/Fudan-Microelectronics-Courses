echo "#### fixSpace  <infile"
fixSpace  <infile
