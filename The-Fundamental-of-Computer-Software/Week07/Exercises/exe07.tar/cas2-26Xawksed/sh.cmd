echo " awk 'NF >0' text "
awk 'NF >0' text
echo " sed '/^$/d' text "
sed '/^$/d' text
echo " awk 'NR >10' text"
awk 'NR >10' text
echo " sed '1,10d' text"
sed '1,10d' text
echo " awk 'NR <5' text"
awk 'NR <5' text
echo " sed '5,$d' text"
sed '5,$d' text
echo " awk 'NR==5, NR==8' text"
awk 'NR==5, NR==8' text
echo " sed '5,8!d' text"
sed '5,8!d' text
echo " awk '{print \$0 "\\"}' text"
awk '{print $0 "\\"}' text
echo " sed 's/$/\\/' text"
sed 's/$/\\/' text
echo " awk '{print "\\t" \$0}' text"
awk '{print "\t" $0}' text
echo " sed 's/^/\t/' text"
sed 's/^/\t/' text
