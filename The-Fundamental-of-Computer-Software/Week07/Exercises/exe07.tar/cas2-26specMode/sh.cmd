awk '
	BEGIN {print "Starting>>>" }
	{print FILENAME, NR, $0; words+=NF }
	END {printf "lines=%d, words=%d\n", NR, words}'  text

