echo "#### cat text"
cat text
echo "#### cat pfile1"
cat pfile1
echo "#### awk -f pfile1 text"
awk -f pfile1 text
echo "#### cat pfile2"
cat pfile2
echo "#### awk -f pfile2 text"
awk -f pfile2 text
