echo "#### getdev <cell_dev"
getdev <cell_dev
