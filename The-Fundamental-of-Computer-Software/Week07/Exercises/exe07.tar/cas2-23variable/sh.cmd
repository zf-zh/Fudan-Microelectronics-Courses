echo "#### cat text"
cat text
echo "#### awk {print \$2, \$1}"
awk '{print $2, $1}' text
echo "#### awk {print \$1 \$2}"
awk '{print $1 $2}' text
echo "#### awk \$1 > \$2"
awk '$1 > $2' text
echo "#### awk NR == 2, NR == 3"
awk 'NR == 2, NR == 3' text
