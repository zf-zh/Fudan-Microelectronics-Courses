echo "#### fixLine <infile "
fixLine <infile
