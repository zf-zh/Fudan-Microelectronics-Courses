echo "#### getGPA <course "
getGPA <course
