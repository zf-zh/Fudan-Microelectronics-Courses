echo "#### cat text"
cat text
echo "#### awk \$2 > \$1 + 100"
awk '$2 > $1 + 100' text
echo "#### awk NR%2 == 0 && \$1 !~ /abc/ "
awk 'NR%2 == 0 && $1 !~ /abc/' text
echo "#### awk NR%2 != 0 && \$1 > \"s\""
awk 'NR%2 != 0 && $1 > "s"' text
