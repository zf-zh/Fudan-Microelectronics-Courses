echo "#### getsum  group_num  new_num "
getsum  group_num  new_num
echo "#### cat new_num"
cat new_num
