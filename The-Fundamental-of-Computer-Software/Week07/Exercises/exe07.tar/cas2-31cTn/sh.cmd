echo "#### cTn  circuit  net  s0"
cTn  circuit  net  s0
echo "#### cat net"
cat net
