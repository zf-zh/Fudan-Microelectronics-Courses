echo "#### cat text"
cat text
echo "#### awk /ab|cd/"
awk '/ab|cd/' text
echo "#### awk \$2 !~ /abc/"
awk '$2 !~ /abc/' text
echo "#### awk \$2 ~ /abc/"
awk '$2 ~ /abc/' text
echo "#### awk /[Aa]b|[Cc]d/"
awk '/[Aa]b|[Cc]d/' text
echo "#### awk /start/, /stop/"
awk '/start/, /stop/' text
