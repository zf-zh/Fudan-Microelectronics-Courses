echo "#### sed -n 1r x.txt text"
sed -n '1r x.txt' text
echo "#### sed 1r x.txt text"
sed '1r x.txt' text
