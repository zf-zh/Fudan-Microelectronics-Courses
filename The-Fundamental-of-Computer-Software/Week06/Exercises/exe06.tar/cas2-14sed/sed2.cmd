echo "#### sed 3,4d text >a.txt"
sed '3,4d' text >a.txt
echo "#### cat a.txt"
cat a.txt
echo "#### sed -n 3,4d text >b.txt"
sed -n '3,4d' text >b.txt
echo "#### cat b.txt"
cat b.txt
echo "#### sed 3,4p text >c.txt"
sed '3,4p' text >c.txt
echo "#### cat c.txt"
cat c.txt
echo "#### sed -n 3,4p text >d.txt"
sed -n '3,4p' text >d.txt
echo "#### cat d.txt"
cat d.txt

