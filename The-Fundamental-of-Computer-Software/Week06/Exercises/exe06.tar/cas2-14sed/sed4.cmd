echo "#### sed 1,2w y.txt text"
sed '1,2w y.txt' text
echo "#### cat y.txt"
cat y.txt
echo "#### sed -n 1,2w z.txt text"
sed -n '1,2w z.txt' text
echo "#### cat z.txt"
cat z.txt

