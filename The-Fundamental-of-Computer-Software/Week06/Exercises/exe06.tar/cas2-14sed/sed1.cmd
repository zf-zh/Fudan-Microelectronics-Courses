echo "#### sed 1,2!d text"
sed '1,2!d' text
echo "#### sed 3,\$d text"
sed '3,$d' text
echo "#### sed -n 1,2p text"
sed -n '1,2p' text
echo "#### sed -n 3,\$!p text "
sed -n '3,$!p' text
echo "#### sed 1,2p text "
sed '1,2p' text
echo "#### sed 3,\$!p text "
sed '3,$!p' text

