echo "#### getcha2b >cha2b"
getcha2b >cha2b
echo "#### chmod +x cha2b"
chmod +x cha2b
echo "#### cha2b"
cha2b
ls
