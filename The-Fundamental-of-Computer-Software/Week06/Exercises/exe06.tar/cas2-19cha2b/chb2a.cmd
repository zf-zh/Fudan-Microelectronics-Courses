echo "#### getchb2a >chb2a"
getchb2a >chb2a
echo "#### chmod +x chb2a"
chmod +x chb2a
echo "#### chb2a"
chb2a
ls
