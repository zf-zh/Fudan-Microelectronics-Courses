echo "#### rm a.ND b.ND AB"
rm a.ND b.ND AB
