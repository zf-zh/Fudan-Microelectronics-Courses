echo "#### c2d ND a"
c2d ND a
echo "#### c2d ND b"
c2d ND b
echo "#### cat a.ND b.ND >AB"
cat a.ND b.ND >AB
