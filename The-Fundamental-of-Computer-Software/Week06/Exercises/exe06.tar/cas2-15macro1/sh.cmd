echo "#### sed 's/.*/cp & &.bak/' <text ####"
sed 's/.*/cp &� �&.bak/' <text
