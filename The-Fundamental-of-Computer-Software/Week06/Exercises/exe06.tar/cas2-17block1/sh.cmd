echo "#### sed -nf sfile text ####"
sed -nf sfile text
