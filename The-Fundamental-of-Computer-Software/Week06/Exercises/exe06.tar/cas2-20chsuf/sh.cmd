echo "#### chsuf a b "
chsuf a b
ls
