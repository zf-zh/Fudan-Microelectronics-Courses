echo "#### sed -f sfile text ####"
sed -f sfile text
