echo "#### c2n  circuit  net  s0"
c2n  circuit  net  s0
echo "#### cat circuit"
cat circuit
echo "#### cat s0 "
cat s0
echo "#### cat net "
cat net
