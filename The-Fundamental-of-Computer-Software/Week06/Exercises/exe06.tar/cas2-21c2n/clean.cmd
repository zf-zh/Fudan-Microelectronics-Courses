rm -f net s0
